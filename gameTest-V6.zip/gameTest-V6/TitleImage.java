import greenfoot.*;

public class TitleImage extends Actor
{
    public TitleImage()
    {
        GreenfootImage img = new GreenfootImage("GameTitle.png");
        setImage(img);
        img.scale(350, 200);
    }
}
